# Trenches Factory

Educational Solana token factory / bonding-curve launchpad inspired by tren.ch rules.

> **Warning**: This is a learning template only.  
> It is **not** the real tren.ch protocol, has **not** been audited, and should **never** be used with real funds on mainnet.

## Features (inspired by docs)

- Create token via Factory
- Simple constant-product bonding curve
- Max 2.5% pre-bond holding limit (concept)
- 60-second create cooldown per wallet
- Migration threshold concept
- Basic buy / sell against the curve

## Stack

- Anchor (Solana program)
- Next.js + TypeScript (frontend)
- @coral-xyz/anchor + @solana/web3.js

## Getting Started

```bash
# Install Anchor + Solana CLI first
anchor build
anchor deploy

cd app
npm install
npm run dev
```

## Project Structure

```
Trenches-Factory/
├── programs/trench_factory/   # Solana program (Anchor)
├── app/                       # Simple Next.js frontend
├── Anchor.toml
├── package.json
└── README.md
```

## Important

This code is for educational purposes only.  
Real launchpads require extensive security work, proper curve math, access control, fee distribution, migration logic, etc.
