use anchor_lang::prelude::*;
use anchor_spl::token::{Mint, Token};

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS");

// Inspired by tren.ch rules
const CREATE_COOLDOWN_SECS: i64 = 60; // 60 seconds
const MIGRATION_THRESHOLD_LAMPORTS: u64 = 10_000_000_000; // example ~10 SOL

#[program]
pub mod trench_factory {
    use super::*;

    pub fn initialize_factory(ctx: Context<InitializeFactory>) -> Result<()> {
        let factory = &mut ctx.accounts.factory;
        factory.authority = ctx.accounts.authority.key();
        factory.bump = ctx.bumps.factory;
        factory.total_tokens_created = 0;
        Ok(())
    }

    pub fn create_token(
        ctx: Context<CreateToken>,
        name: String,
        symbol: String,
        _uri: String,
    ) -> Result<()> {
        let clock = Clock::get()?;
        let factory = &mut ctx.accounts.factory;

        // Cooldown check (inspired by 60s rule)
        if let Some(last) = factory.last_create_ts {
            require!(
                clock.unix_timestamp - last >= CREATE_COOLDOWN_SECS,
                FactoryError::CreateCooldown
            );
        }

        let bonding = &mut ctx.accounts.bonding_curve;
        bonding.mint = ctx.accounts.mint.key();
        bonding.creator = ctx.accounts.creator.key();
        bonding.virtual_sol_reserves = 30_000_000_000;
        bonding.virtual_token_reserves = 1_073_000_000_000_000;
        bonding.real_sol_reserves = 0;
        bonding.real_token_reserves = 800_000_000_000_000;
        bonding.complete = false;
        bonding.bump = ctx.bumps.bonding_curve;

        factory.last_create_ts = Some(clock.unix_timestamp);
        factory.total_tokens_created = factory.total_tokens_created.checked_add(1).unwrap();

        msg!("Token created: {} ({})", name, symbol);
        Ok(())
    }

    pub fn buy(ctx: Context<Buy>, sol_amount: u64, min_tokens_out: u64) -> Result<()> {
        let bonding = &mut ctx.accounts.bonding_curve;
        require!(!bonding.complete, FactoryError::AlreadyMigrated);

        // Very simplified constant product calculation
        // DO NOT use this math in production
        let token_amount = calculate_tokens_out(
            bonding.virtual_sol_reserves,
            bonding.virtual_token_reserves,
            sol_amount,
        )?;

        require!(token_amount >= min_tokens_out, FactoryError::SlippageExceeded);

        bonding.real_sol_reserves = bonding
            .real_sol_reserves
            .checked_add(sol_amount)
            .unwrap();
        bonding.virtual_sol_reserves = bonding
            .virtual_sol_reserves
            .checked_add(sol_amount)
            .unwrap();
        bonding.virtual_token_reserves = bonding
            .virtual_token_reserves
            .checked_sub(token_amount)
            .unwrap();
        bonding.real_token_reserves = bonding
            .real_token_reserves
            .checked_sub(token_amount)
            .unwrap();

        if bonding.real_sol_reserves >= MIGRATION_THRESHOLD_LAMPORTS {
            bonding.complete = true;
            msg!("Bonding curve complete – ready for migration");
        }

        Ok(())
    }
}

// ---------- Accounts ----------

#[derive(Accounts)]
pub struct InitializeFactory<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + Factory::INIT_SPACE,
        seeds = [b"factory"],
        bump
    )]
    pub factory: Account<'info, Factory>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CreateToken<'info> {
    #[account(mut, seeds = [b"factory"], bump = factory.bump)]
    pub factory: Account<'info, Factory>,

    #[account(
        init,
        payer = creator,
        space = 8 + BondingCurve::INIT_SPACE,
        seeds = [b"bonding", mint.key().as_ref()],
        bump
    )]
    pub bonding_curve: Account<'info, BondingCurve>,

    pub mint: Account<'info, Mint>,

    #[account(mut)]
    pub creator: Signer<'info>,
    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct Buy<'info> {
    #[account(mut, seeds = [b"bonding", mint.key().as_ref()], bump = bonding_curve.bump)]
    pub bonding_curve: Account<'info, BondingCurve>,
    pub mint: Account<'info, Mint>,
    #[account(mut)]
    pub buyer: Signer<'info>,
    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
}

// ---------- State ----------

#[account]
#[derive(InitSpace)]
pub struct Factory {
    pub authority: Pubkey,
    pub total_tokens_created: u64,
    pub last_create_ts: Option<i64>,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct BondingCurve {
    pub mint: Pubkey,
    pub creator: Pubkey,
    pub virtual_sol_reserves: u64,
    pub virtual_token_reserves: u64,
    pub real_sol_reserves: u64,
    pub real_token_reserves: u64,
    pub complete: bool,
    pub bump: u8,
}

// ---------- Helpers & Errors ----------

fn calculate_tokens_out(virtual_sol: u64, virtual_token: u64, sol_in: u64) -> Result<u64> {
    // Extremely simplified – real curves need careful math + overflow protection
    let k = (virtual_sol as u128)
        .checked_mul(virtual_token as u128)
        .unwrap();
    let new_sol = (virtual_sol as u128)
        .checked_add(sol_in as u128)
        .unwrap();
    let new_token = k.checked_div(new_sol).unwrap();
    let tokens_out = (virtual_token as u128)
        .checked_sub(new_token)
        .unwrap();
    Ok(tokens_out as u64)
}

#[error_code]
pub enum FactoryError {
    #[msg("Create cooldown not finished (60s)")]
    CreateCooldown,
    #[msg("Bonding curve already migrated")]
    AlreadyMigrated,
    #[msg("Slippage exceeded")]
    SlippageExceeded,
}
