export default function Home() {
  return (
    <main style={{ padding: "40px", fontFamily: "system-ui", maxWidth: "800px", margin: "0 auto" }}>
      <h1 style={{ fontSize: "2.5rem", marginBottom: "8px" }}>Trenches Factory</h1>
      <p style={{ color: "#888", marginBottom: "32px" }}>
        Educational bonding-curve launchpad inspired by tren.ch
      </p>

      <div style={{ 
        background: "#111", 
        border: "1px solid #333", 
        borderRadius: "12px", 
        padding: "24px",
        marginBottom: "24px"
      }}>
        <h2 style={{ marginTop: 0 }}>Create Token</h2>
        <p style={{ color: "#aaa", fontSize: "14px" }}>
          This is a placeholder UI. Connect your wallet and call the Anchor program to create a token.
        </p>
        <button style={{
          background: "#22c55e",
          color: "black",
          border: "none",
          padding: "10px 20px",
          borderRadius: "8px",
          fontWeight: "bold",
          cursor: "pointer"
        }}>
          Create Coin
        </button>
      </div>

      <div style={{ 
        background: "#111", 
        border: "1px solid #333", 
        borderRadius: "12px", 
        padding: "24px"
      }}>
        <h2 style={{ marginTop: 0 }}>Buy on Curve</h2>
        <p style={{ color: "#aaa", fontSize: "14px" }}>
          Simple buy interface against the bonding curve.
        </p>
        <input 
          type="number" 
          placeholder="SOL amount" 
          style={{
            width: "100%",
            padding: "10px",
            marginBottom: "12px",
            borderRadius: "8px",
            border: "1px solid #444",
            background: "#000",
            color: "white"
          }}
        />
        <button style={{
          background: "#3b82f6",
          color: "white",
          border: "none",
          padding: "10px 20px",
          borderRadius: "8px",
          fontWeight: "bold",
          cursor: "pointer"
        }}>
          Buy
        </button>
      </div>

      <p style={{ marginTop: "40px", fontSize: "13px", color: "#666" }}>
        ⚠️ This is educational only. Not the real tren.ch protocol. Do not use with real funds.
      </p>
    </main>
  );
}
