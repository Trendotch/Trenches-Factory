export const metadata = {
  title: "Trenches Factory",
  description: "Educational Solana bonding curve factory",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body style={{ margin: 0, background: "#0a0a0a", color: "white" }}>
        {children}
      </body>
    </html>
  );
}
